using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementScript : MonoBehaviour
{
    public float movmentSpeed;
    public float jumpForce;
    public Rigidbody2D rig;
    public SpriteRenderer spRender;
    private bool grounded;

    // FixedUpdate called every 0.02 seconds
    void FixedUpdate()
    {
        float xInput = Input.GetAxis("Horizontal");
        rig.velocity = new Vector2(xInput * movmentSpeed, rig.velocity.y);
        if (xInput < 0)
        {
            // Moving right
            spRender.flipX = false;
        }
        else if (xInput > 0)
        {
            // Moving Left
            spRender.flipX = true;
        }


        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow) && grounded)
        {
            rig.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

            grounded = false;
        }

    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Platform"))
        {
            grounded = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Platform"))
        {
            grounded = false;
        }
    }
}
