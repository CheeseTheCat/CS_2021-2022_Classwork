# Introduction

2D Path provides a set of tools to edit polygons and b-splines in custom EditorWindow and the SceneView.
